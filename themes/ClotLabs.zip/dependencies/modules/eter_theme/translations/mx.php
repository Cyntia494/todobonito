<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{eter_theme}prestashop>eter_theme_c44abab03d7a93acff211fbbd21f9d1e'] = 'Personalizaciones del tema';
$_MODULE['<{eter_theme}prestashop>eter_theme_5a1d3f45002445a078cd8e20a5303349'] = 'El modulo base de los temas de eterlabs, permitirá gestionar datos importantes para el tema';
$_MODULE['<{eter_theme}prestashop>customcss_dbefa95b16ff35d18f2f2e204d9e9b0f'] = 'El css ha sido guardado';
$_MODULE['<{eter_theme}prestashop>customcss_79b4ed57556973fd1d2f2b03e825f557'] = 'El css no ha sido guardado';
$_MODULE['<{eter_theme}prestashop>customcss_bdb9d729ab2ee5f4828c7984e249316b'] = 'Guardar css';
$_MODULE['<{eter_theme}prestashop>customcss_853b843698e6b366a609a376cd6d0f2a'] = 'Editor css';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_e43b5b8f6eae75e677887c0cf0f009d9'] = 'La configuración ha sido guardada';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_213ec50ef623fb970d4ae1d4b23bae7f'] = 'La configuración  no ha sido guardada';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_b17c6e89473f1302174604d97493f6bf'] = 'Colores del tema';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_9f7d014590056b968cbb6cbbf43962a0'] = 'Usar esta configuración de colores';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_93cba07454f06a4a960172bbd6e2a435'] = 'Si';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_2e1fb300b1b000f0ed9b9a0b84100ad0'] = 'Color principal';
$_MODULE['<{eter_theme}prestashop>eterlabsconfig_c6f5e1553856f2ee395b205848e94307'] = 'Color del header';
$_MODULE['<{eter_theme}prestashop>demo_d898b20717458f5bd5676bfdc15b6031'] = 'Esto es un demos, todas las ordenes registradas no son relaes';
$_MODULE['<{eter_theme}prestashop>demo_a2d1ae2737f38e67168a23a10b1b9c88'] = 'Comprar este tema';
