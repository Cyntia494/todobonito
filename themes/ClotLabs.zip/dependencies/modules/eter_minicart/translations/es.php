<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{eter_minicart}prestashop>eter_minicart_227a89378e1030e2beeeffa3bdb1299f'] = 'Mini Carrito';
$_MODULE['<{eter_minicart}prestashop>eter_minicart_9c1d00491a3ce2a718d23ec2b575b62d'] = 'Muestra un carrito desplegable en el header';
$_MODULE['<{eter_minicart}prestashop>minicart_dae3b417a0fc4a49e851ce55d6d49551'] = 'Mi carrito';
$_MODULE['<{eter_minicart}prestashop>minicart_3d0d1f906e27800531e054a3b6787b7c'] = 'Cantidad:';
$_MODULE['<{eter_minicart}prestashop>minicart_f2c12ae14393ffc83551d56f32bb03cc'] = 'Precio:';
$_MODULE['<{eter_minicart}prestashop>minicart_ce2c8aed9c2fa0cfbed56cbda4d8bf07'] = 'Carrito vacío';
$_MODULE['<{eter_minicart}prestashop>minicart_96b0141273eabab320119c467cdcaf17'] = 'Total';
$_MODULE['<{eter_minicart}prestashop>minicart_3e5ff7904693ae334d0d0811095c23f3'] = 'Editar Carrito';
$_MODULE['<{eter_minicart}prestashop>minicart_6ff063fbc860a79759a7369ac32cee22'] = 'Pagar';
