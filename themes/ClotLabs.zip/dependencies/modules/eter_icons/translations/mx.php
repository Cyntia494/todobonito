<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{eter_icons}prestashop>eter_icons_e9bcbba7c77d316adf7fe2852706c1b6'] = 'Iconos de pie de página';
$_MODULE['<{eter_icons}prestashop>eter_icons_61da5cc7379ecd7dfb188b66dcfa2e9f'] = 'Permite agregar iconos en el pie de página';
$_MODULE['<{eter_icons}prestashop>eter_icons_16068f066306ad1d439d944b27b751b5'] = 'Por favor selecciona una imagen';
$_MODULE['<{eter_icons}prestashop>eter_icons_2d5c7c4961a6fd2acf09ba9de73787ab'] = 'Por favor verifique el alto y ancho de la imagen';
$_MODULE['<{eter_icons}prestashop>eter_icons_deb27e3c9e8fed74f05f9cae86c90659'] = 'Por favor revise los permisos de escritura del servidor';
$_MODULE['<{eter_icons}prestashop>adminetericons_48c5359d0322e3c738a86f001ac6815c'] = 'Por favor verifique el directorio  %s (Permisos de escritura requeridos).';
$_MODULE['<{eter_icons}prestashop>adminetericons_13b9a522488c256f183ae151caf1ed4a'] = 'El icono ha sido guardado';
$_MODULE['<{eter_icons}prestashop>adminetericons_16b60c6f662479022ed7c5fe10b36f91'] = 'El icono no ha sido guardado';
$_MODULE['<{eter_icons}prestashop>adminetericons_bd1a60ec27cc87f217c86e2cbd32e789'] = 'El icono ha sido borrado';
$_MODULE['<{eter_icons}prestashop>adminetericons_de360c8b5dd9a9fdd592b1c08b3b4a62'] = 'El estatus se ha actualizado';
$_MODULE['<{eter_icons}prestashop>adminetericons_f86f7b91afe27e79305a6b07bdb0d3c0'] = 'El estatus no se ha actualizado';
$_MODULE['<{eter_icons}prestashop>adminetericons_545e3e9a9e75ebd8e9af607b5d044895'] = 'Por favor verifique el nombre';
$_MODULE['<{eter_icons}prestashop>adminetericons_cae830e3e869ccbda9eb116fbc4d3071'] = 'Por favor verifique la url';
$_MODULE['<{eter_icons}prestashop>adminetericons_490aa6e856ccf208a054389e47ce0d06'] = 'Id';
$_MODULE['<{eter_icons}prestashop>adminetericons_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imagen';
$_MODULE['<{eter_icons}prestashop>adminetericons_49ee3087348e8d44e1feda1917443987'] = 'Nombre';
$_MODULE['<{eter_icons}prestashop>adminetericons_64f17243f09012102d8d0cd980344c80'] = 'Posición';
$_MODULE['<{eter_icons}prestashop>adminetericons_bd21190449b7e88db48fa0f580a8f666'] = 'Icono';
$_MODULE['<{eter_icons}prestashop>adminetericons_c5adacf458ffcd874c4b204b0a0b8919'] = 'Tamaño de la imagen (128 x 80) pixeles';
$_MODULE['<{eter_icons}prestashop>adminetericons_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activo';
$_MODULE['<{eter_icons}prestashop>adminetericons_93cba07454f06a4a960172bbd6e2a435'] = 'Si';
$_MODULE['<{eter_icons}prestashop>adminetericons_bafd7322c6e97d25b6299b5d6fe8920b'] = 'No';
$_MODULE['<{eter_icons}prestashop>adminetericons_9f2e550f68835210c53e2d21053a501a'] = 'Url destino';
$_MODULE['<{eter_icons}prestashop>adminetericons_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
