<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{eter_popup}prestashop>eter_popup_f24a9a2dcf0974e3c4c3fed9af148cb8'] = 'Ventana emergente';
$_MODULE['<{eter_popup}prestashop>eter_popup_90087cc1392b66f47d51258aeb9e6f73'] = 'Agrega una ventana emergente para el registro al boletín de noticias';
$_MODULE['<{eter_popup}prestashop>eter_popup_16068f066306ad1d439d944b27b751b5'] = 'Por favor seleccione una imagen';
$_MODULE['<{eter_popup}prestashop>eter_popup_2d5c7c4961a6fd2acf09ba9de73787ab'] = 'Por favor revise el alto y ancho de la imagen';
$_MODULE['<{eter_popup}prestashop>eter_popup_deb27e3c9e8fed74f05f9cae86c90659'] = 'Por favor revise los permisos de escritura en el servidor';
$_MODULE['<{eter_popup}prestashop>adminpopup_48c5359d0322e3c738a86f001ac6815c'] = 'Por favor verifique el directorio  %s (Permisos de escritura requeridos).';
$_MODULE['<{eter_popup}prestashop>adminpopup_e43b5b8f6eae75e677887c0cf0f009d9'] = 'La configuración ha sido guardada';
$_MODULE['<{eter_popup}prestashop>adminpopup_213ec50ef623fb970d4ae1d4b23bae7f'] = 'La configuración no ha sido guardada';
$_MODULE['<{eter_popup}prestashop>adminpopup_2ca87f759c13bdbf4f2ffc1eec06ba5f'] = 'Por favor verifique el titulo';
$_MODULE['<{eter_popup}prestashop>adminpopup_2b6feeb02cbf04891aaa336208684190'] = 'Por favor verifique la descripción';
$_MODULE['<{eter_popup}prestashop>adminpopup_cc68ae6b34fef977f8706ef2620573fc'] = 'Ventana emergente';
$_MODULE['<{eter_popup}prestashop>adminpopup_b78a3223503896721cca1303f776159b'] = 'Titulo';
$_MODULE['<{eter_popup}prestashop>adminpopup_b5a7adde1af5c87d7fd797b6245c2a39'] = 'Descipción';
$_MODULE['<{eter_popup}prestashop>adminpopup_be53a0541a6d36f6ecb879fa2c584b08'] = 'Imagen';
$_MODULE['<{eter_popup}prestashop>adminpopup_51162975fca4c571cfe2ebde8586a0bf'] = 'tamaño de la imagen 700 x 450 pixeles';
$_MODULE['<{eter_popup}prestashop>adminpopup_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{eter_popup}prestashop>newsletter_77c576a354d5d6f5e2c1ba50167addf8'] = 'Te has subscrito al boletín de noticias';
