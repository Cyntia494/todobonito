<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{eter_headerlogin}prestashop>eter_headerlogin_8902aafad14b2148bcc6f44acee63292'] = 'Inicio de sesioón en cabecera';
$_MODULE['<{eter_headerlogin}prestashop>eter_headerlogin_e9e7504047b30f13f825fe2fd331f636'] = 'Agregar la sección de inicio de sesión en la cabecera';
